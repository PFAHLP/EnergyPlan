
Chart.register(ChartDataLabels);
//set text to display
var textDisplay = "Home"
maintext();
mainplot = (function() {
    var canvas = document.getElementById('plotCanvas');
    var ctx = canvas.getContext('2d');
    //draw stuff
    var eneryChart = new Chart(ctx,
      config
    );
  })();

  function maintext() {
        var canvas = document.getElementById("textCanvas");
        var ctx = canvas.getContext("2d");

        if (textDisplay == "Home") {
          ctx.font = "30px Arial";
          ctx.fillText("Hello World Home",10,100);
        };

        if (textDisplay != "Home"){
          updatetext(canvas, ctx,textDisplay);
        }
      };

function updatetext(canvas, ctx, text){
  // todo make it load text + variable . text
  //create all the variable files!
  
  if (text == "Car"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Car",10,50);
  }
  if (text == "Flights"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Flights",10,50);
  }
  if (text == "Stuff"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Stuff",10,50);
  }
  if (text == "Heating"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Heating",10,50);
  }
  if (text == "Transport"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Transport",10,50);
  }
  if (text == "Gadgets"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Gadgets",10,50);
  }
  if (text == "Lights"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Lights",10,50);
  }
  if (text == "Biomass"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World Biomass",10,50);
  }
  if (text == "PV farm"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World PV farm",10,50);
  }
  if (text == "PV Roof"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World PV Roof",10,50);
  }
  if (text == "Wave and Tide"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World W N T",10,50);
  }
  if (text == "Wind offshore"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World offshore",10,50);
  }
  if (text == "Wind onshore"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World onshore",10,50);
  }
  if (text == "Solar heating"){
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.font = "30px Arial";
    ctx.fillText("Hello World solar heating",10,50);
  }

}
