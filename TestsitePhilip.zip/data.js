//def colors
const productionBackgroundColor = "#ca4d47"
const productionBorderColor = "#722e2b"
const productionHoverBorderColor = "#d3b5aa"

const consumptionBackgroundColor = "#6bcb4b"
const consumptionBorderColor = "#2f7118"
const consumptionHoverBorderColor = "#b5d3aa"

const productionBorderWidth = 3
const productionHoverBorderWidth = 9

const data = {
labels: [""],
datasets: [
  //production
    {
      label: 'Transport',
      data: [12],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Heating',
      data: [37],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Stuff',
      data: [48],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,

    },
    {
      label: 'Flights',
      data: [30],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },{
      label: 'Car',
      data: [40],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,

    },
    {
      label: 'Lights',
      data: [4],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },{
      label: 'Gadgets',
      data: [5],
      stack: "Stack 1",
      borderColor: productionBorderColor,
      backgroundColor: productionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,

    },

    //consumption
    {
      label: 'Solar heating',
      data: [13],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Wind on land',
      data: [20],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Wind offshore',
      data: [16],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Wind offshore deep',
      data: [32],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Wave and Tide',
      data: [15],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'PV farm',
      data: [50],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'PV Roof',
      data: [5],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
    {
      label: 'Biomass',
      data: [24],
      stack: "Stack 0",
      borderColor: consumptionBorderColor,
      backgroundColor: consumptionBackgroundColor,
      borderWidth: productionBorderWidth,
      hoverBorderWidth: productionHoverBorderWidth,
      borderSkipped: false,
    },
  ]
};
