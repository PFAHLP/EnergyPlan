const config = {
  type: 'bar',
  data: data,
  options: {
    responsive: true,
    scales: {
        xAxes: [{ticks: {mirror: true}},
                {display: false},
                ]
    },
    //make it clickable
    onClick:graphClickEvent,
    //space at the top + bottom
    layout: {
      padding: {
          top: 100,
          bottom: 50,
      }
    },
    //fit it in the container
    maintainAspectRatio: false,
    plugins: {
       title: {
           display: true,
           fullSize: true,
           text: 'Energy usage per day per person',
           color: "#000",
           font: {
                size: 30
            },
       },
        legend: {
            //set to false to remove side bar
            display: false,
            labels: {
                color: "#000"
            }
        },
        //show data labels in chart:
        datalabels: {
                color: '#000',
                textAlign: 'center',

                font: {
                    lineHeight: 1.6,
                    size: 20,
                    style:"normal",
                },
                formatter: function(value, ctx) {
                    displayedValue = ctx.chart.data.labels[ctx.dataIndex] + '\n' + value;
                    displayedName = ctx.dataset.label;
                    //for to small parts
                    if (displayedValue > 11){
                      temp =  displayedName+":" +displayedValue+" kwh"
                      return temp;
                    };
                    if (displayedValue <= 11){
                      return "";
                    };
                }
            },
   },
  },
}

//adding the click functionality to the plot
//outgoing
function graphClickEvent(event, ctx, mainplot){
    //get index and label
    indexOnClick = ctx[0]. datasetIndex
    labelOnClick = data.datasets[indexOnClick].label

    //reset look to "normal"
    for (let i = 0; i < data.datasets.length; i++) {
      data.datasets[i].borderWidth = 3;

    }
    //cange to bigger borderWidth
    data.datasets[indexOnClick].borderWidth = 9 ;
    mainplot.update();
    //load new content on the left
    textDisplay = labelOnClick;
    maintext();
  }
